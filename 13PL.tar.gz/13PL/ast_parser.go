package main

type MapLiteral struct {
	Pairs map[Expression]Expression
}

func (m *MapLiteral) expressionNode() {}

type IndexExpression struct {
	Left  Expression
	Index Expression
}

func (ie *IndexExpression) expressionNode() {}

type IndexAssignmentStatement struct {
	ArrayName string
	Index     Expression
	Value     Expression
}

func (ia *IndexAssignmentStatement) statementNode() {}

type WhileStatement struct {
	Condition Expression
	Body      []Statement
}

func (w *WhileStatement) statementNode() {}