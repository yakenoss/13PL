package main

import (
	"fmt"
	"os"
)

func main() {
	// Si se pasa un archivo como argumento (ej: ./mi-lenguaje script.lang)
	if len(os.Args) > 1 {
		filePath := os.Args[1]
		contenido, err := os.ReadFile(filePath)
		if err != nil {
			fmt.Printf("Error al abrir el archivo '%s': %v\n", filePath, err)
			os.Exit(1)
		}

		env := NewEnvironment()
		lexer := NewLexer(string(contenido))
		parser := NewParser(lexer)

		for parser.curToken.Type != TOKEN_EOF {
			stmt := parser.ParseStatement()
			if stmt != nil {
				Eval(stmt, env)
			}
			parser.nextToken()
		}
		return
	}

	// Si no hay argumentos, se inicia la consola interactiva (REPL)
	StartREPL(os.Stdin, os.Stdout)
}