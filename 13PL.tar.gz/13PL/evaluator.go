package main

import (
	_ "fmt"
)

type BuiltinFunction func(args ...interface{}) interface{}

var builtins = map[string]BuiltinFunction{
	"len": func(args ...interface{}) interface{} {
		if len(args) != 1 {
			return 0
		}
		switch arg := args[0].(type) {
		case string:
			return len(arg)
		case []interface{}:
			return len(arg)
		default:
			return 0
		}
	},

	"push": func(args ...interface{}) interface{} {
		if len(args) != 2 {
			return 0
		}
		if array, ok := args[0].([]interface{}); ok {
			return append(array, args[1])
		}
		return 0
	},

	"pop": func(args ...interface{}) interface{} {
		if len(args) != 1 {
			return 0
		}
		if array, ok := args[0].([]interface{}); ok {
			if len(array) == 0 {
				return 0
			}
			return array[len(array)-1]
		}
		return 0
	},

	"map": func(args ...interface{}) interface{} {
		if len(args) != 2 {
			return 0
		}
		array, isArray := args[0].([]interface{})
		if !isArray {
			return 0
		}
		fn := args[1]
		var result []interface{}
		for _, item := range array {
			res := applyFunction(fn, []interface{}{item})
			result = append(result, res)
		}
		return result
	},

	"filter": func(args ...interface{}) interface{} {
		if len(args) != 2 {
			return 0
		}
		array, isArray := args[0].([]interface{})
		if !isArray {
			return 0
		}
		fn := args[1]
		var result []interface{}
		for _, item := range array {
			res := applyFunction(fn, []interface{}{item})
			if cond, ok := res.(int); ok && cond > 0 {
				result = append(result, item)
			} else if condBool, ok := res.(bool); ok && condBool {
				result = append(result, item)
			}
		}
		return result
	},

	"reduce": func(args ...interface{}) interface{} {
		if len(args) != 3 {
			return 0
		}
		array, isArray := args[0].([]interface{})
		if !isArray {
			return 0
		}
		fn := args[1]
		acumulador := args[2]
		for _, item := range array {
			acumulador = applyFunction(fn, []interface{}{acumulador, item})
		}
		return acumulador
	},
}

type ReturnValue struct {
	Value interface{}
}

func applyFunction(fn interface{}, args []interface{}) interface{} {
	switch f := fn.(type) {
	case BuiltinFunction:
		return f(args...)

	case *FunctionObject:
		localEnv := NewEnclosedEnvironment(f.Env)
		for i, param := range f.Parameters {
			if i < len(args) {
				localEnv.store[param] = args[i]
			}
		}
		for _, stmt := range f.Body {
			res := Eval(stmt, localEnv)
			if ret, isReturn := res.(*ReturnValue); isReturn {
				return ret.Value
			}
		}
		return 0
	}
	return 0
}

func evalWhileStatement(stmt *WhileStatement, env *Environment) interface{} {
	var result interface{} = 0

	for {
		condVal := Eval(stmt.Condition, env)
		isTrue := false
		if valInt, ok := condVal.(int); ok && valInt > 0 {
			isTrue = true
		} else if valBool, ok := condVal.(bool); ok && valBool {
			isTrue = true
		}

		if !isTrue {
			break
		}

		shouldBreakLoop := false
		for _, bodyStmt := range stmt.Body {
			result = Eval(bodyStmt, env)

			if _, isBreak := result.(*BreakValue); isBreak {
				shouldBreakLoop = true
				break
			}

			if _, isContinue := result.(*ContinueValue); isContinue {
				break
			}

			if ret, isReturn := result.(*ReturnValue); isReturn {
				return ret
			}
		}

		if shouldBreakLoop {
			break
		}
	}

	return result
}

func Eval(node Node, env *Environment) interface{} {
	switch n := node.(type) {

	case *MapLiteral:
		mapObj := make(map[string]interface{})
		for keyExpr, valExpr := range n.Pairs {
			keyVal := Eval(keyExpr, env)
			if keyStr, isString := keyVal.(string); isString {
				mapObj[keyStr] = Eval(valExpr, env)
			}
		}
		return mapObj

	case *IndexExpression:
		left := Eval(n.Left, env)
		index := Eval(n.Index, env)

		if array, isArray := left.([]interface{}); isArray {
			if idx, isInt := index.(int); isInt {
				if idx >= 0 && idx < len(array) {
					return array[idx]
				}
			}
		}

		if mapObj, isMap := left.(map[string]interface{}); isMap {
			if key, isString := index.(string); isString {
				return mapObj[key]
			}
		}
		return 0

	case *WhileStatement:
		return evalWhileStatement(n, env)

	case *BreakStatement:
		return &BreakValue{}

	case *ContinueStatement:
		return &ContinueValue{}

	case *FunctionLiteral:
		return &FunctionObject{
			Parameters: n.Parameters,
			Body:       n.Body,
			Env:        env,
		}
	}

	return 0
}
