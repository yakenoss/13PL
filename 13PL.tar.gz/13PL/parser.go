package main

type Precedence int

const (
	_ Precedence = iota
	LOWEST
	EQUALS      // ==
	LESSGREATER // > o <
	SUM         // +
	PRODUCT     // *
	PREFIX      // -X o !X
	CALL        // myFunction(X)
)

type Parser struct {
	lexer     *Lexer
	curToken  Token
	peekToken Token
}

func NewParser(lexer *Lexer) *Parser {
	p := &Parser{lexer: lexer}
	p.nextToken()
	p.nextToken()
	return p
}

func (p *Parser) nextToken() {
	p.curToken = p.peekToken
	p.peekToken = p.lexer.NextToken()
}

func (p *Parser) ParseStatement() Statement {
	switch p.curToken.Type {
	case TOKEN_WHILE:
		return p.parseWhileStatement()
	case TOKEN_BREAK:
		return &BreakStatement{}
	case TOKEN_CONTINUE:
		return &ContinueStatement{}
	default:
		return p.parseExpressionStatement()
	}
}

func (p *Parser) parseWhileStatement() *WhileStatement {
	stmt := &WhileStatement{}
	p.nextToken()

	stmt.Condition = p.parseExpression(LOWEST)

	if p.peekToken.Type == TOKEN_LBRACE {
		p.nextToken()
	}

	p.nextToken()

	for p.curToken.Type != TOKEN_RBRACE && p.curToken.Type != TOKEN_EOF {
		st := p.ParseStatement()
		if st != nil {
			stmt.Body = append(stmt.Body, st)
		}
		p.nextToken()
	}

	return stmt
}

func (p *Parser) parseExpressionStatement() Statement {
	expr := p.parseExpression(LOWEST)
	if expr == nil {
		return nil
	}
	return &ExpressionStatement{Expression: expr}
}

func (p *Parser) parseExpression(precedence Precedence) Expression {
	switch p.curToken.Type {
	case TOKEN_IDENT:
		return &Identifier{Name: p.curToken.Literal}
	case TOKEN_FUNCTION:
		return p.parseFunctionLiteral()
	default:
		return nil
	}
}

func (p *Parser) parseFunctionLiteral() Expression {
	lit := &FunctionLiteral{}

	if p.peekToken.Type == TOKEN_LPAREN {
		p.nextToken()
	}

	// Parametros de la función
	for p.peekToken.Type != TOKEN_RPAREN && p.peekToken.Type != TOKEN_EOF {
		p.nextToken()
		if p.curToken.Type == TOKEN_IDENT {
			lit.Parameters = append(lit.Parameters, p.curToken.Literal)
		}
	}

	if p.peekToken.Type == TOKEN_RPAREN {
		p.nextToken()
	}

	if p.peekToken.Type == TOKEN_LBRACE {
		p.nextToken()
	}

	p.nextToken()

	// Cuerpo de la función
	for p.curToken.Type != TOKEN_RBRACE && p.curToken.Type != TOKEN_EOF {
		st := p.ParseStatement()
		if st != nil {
			lit.Body = append(lit.Body, st)
		}
		p.nextToken()
	}

	return lit
}

type ExpressionStatement struct {
	Expression Expression
}

func (es *ExpressionStatement) statementNode() {}