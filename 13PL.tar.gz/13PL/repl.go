package main

import (
	"bufio"
	"fmt"
	"io"
	"strings"
)

const PROMPT = ">> "

func StartREPL(in io.Reader, out io.Writer) {
	scanner := bufio.NewScanner(in)
	env := NewEnvironment()

	fmt.Fprintln(out, "=== MiLenguaje REPL v1.0 ===")
	fmt.Fprintln(out, "Escribe código y presiona Enter. Escribe 'salir' o 'exit' para terminar.")
	fmt.Fprint(out, PROMPT)

	for scanner.Scan() {
		line := scanner.Text()

		if strings.TrimSpace(line) == "exit" || strings.TrimSpace(line) == "salir" {
			fmt.Fprintln(out, "¡Hasta luego!")
			break
		}

		if strings.TrimSpace(line) == "" {
			fmt.Fprint(out, PROMPT)
			continue
		}

		lexer := NewLexer(line)
		parser := NewParser(lexer)

		for parser.curToken.Type != TOKEN_EOF {
			stmt := parser.ParseStatement()
			if stmt != nil {
				evaluated := Eval(stmt, env)
				if evaluated != nil && evaluated != 0 {
					fmt.Fprintf(out, "=> %v\n", evaluated)
				}
			}
			parser.nextToken()
		}

		fmt.Fprint(out, PROMPT)
	}
}
