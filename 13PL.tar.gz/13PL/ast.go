package main

// Tipos base del Árbol de Sintaxis Abstracta (AST)
type Node interface{}

type Statement interface {
	Node
	statementNode()
}

type Expression interface {
	Node
	expressionNode()
}

type Program struct {
	Statements []Statement
}

type Identifier struct {
	Name string
}

func (i *Identifier) expressionNode() {}

type BreakStatement struct{}

func (b *BreakStatement) statementNode() {}

type ContinueStatement struct{}

func (c *ContinueStatement) statementNode() {}

type FunctionObject struct {
	Parameters []string
	Body       []Statement
	Env        *Environment
}

type FunctionLiteral struct {
	Parameters []string
	Body       []Statement
}

func (fl *FunctionLiteral) expressionNode() {}

type Environment struct {
	store map[string]interface{}
	outer *Environment
}

func NewEnvironment() *Environment {
	return &Environment{
		store: make(map[string]interface{}),
		outer: nil,
	}
}

func NewEnclosedEnvironment(outer *Environment) *Environment {
	env := NewEnvironment()
	env.outer = outer
	return env
}

func (e *Environment) Get(name string) (interface{}, bool) {
	val, ok := e.store[name]
	if !ok && e.outer != nil {
		return e.outer.Get(name)
	}
	return val, ok
}

func (e *Environment) Set(name string, val interface{}) interface{} {
	if _, ok := e.store[name]; ok {
		e.store[name] = val
		return val
	}

	if e.outer != nil {
		if _, ok := e.outer.Get(name); ok {
			return e.outer.Set(name, val)
		}
	}

	e.store[name] = val
	return val
}
type BreakValue struct{}
type ContinueValue struct{}
