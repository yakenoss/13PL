package main

import (
	"unicode"
)

type TokenType string

const (
	TOKEN_EOF     TokenType = "EOF"
	TOKEN_ILLEGAL TokenType = "ILLEGAL"

	// Identificadores y literales
	TOKEN_IDENT  TokenType = "IDENT"
	TOKEN_INT    TokenType = "INT"
	TOKEN_STRING TokenType = "STRING"

	// Operadores
	TOKEN_ASSIGN   TokenType = "="
	TOKEN_PLUS     TokenType = "+"
	TOKEN_MINUS    TokenType = "-"
	TOKEN_BANG     TokenType = "!"
	TOKEN_ASTERISK TokenType = "*"
	TOKEN_SLASH    TokenType = "/"
	TOKEN_MOD      TokenType = "%"

	TOKEN_EQ     TokenType = "=="
	TOKEN_NOT_EQ TokenType = "!="
	TOKEN_LT     TokenType = "<"
	TOKEN_GT     TokenType = ">"

	// Delimitadores
	TOKEN_COMMA     TokenType = ","
	TOKEN_SEMICOLON TokenType = ";"
	TOKEN_COLON     TokenType = ":"

	TOKEN_LPAREN TokenType = "("
	TOKEN_RPAREN TokenType = ")"
	TOKEN_LBRACE TokenType = "{"
	TOKEN_RBRACE TokenType = "}"
	TOKEN_LBRACK TokenType = "["
	TOKEN_RBRACK TokenType = "]"

	// Palabras clave
	TOKEN_FUNCTION TokenType = "FUNCTION"
	TOKEN_VAR      TokenType = "VAR"
	TOKEN_TRUE     TokenType = "TRUE"
	TOKEN_FALSE    TokenType = "FALSE"
	TOKEN_IF       TokenType = "IF"
	TOKEN_ELSE     TokenType = "ELSE"
	TOKEN_RETURN   TokenType = "RETURN"
	TOKEN_WHILE    TokenType = "WHILE"
	TOKEN_BREAK    TokenType = "BREAK"
	TOKEN_CONTINUE TokenType = "CONTINUE"
)

type Token struct {
	Type    TokenType
	Literal string
}

var keywords = map[string]TokenType{
	"fn":       TOKEN_FUNCTION,
	"var":      TOKEN_VAR,
	"true":     TOKEN_TRUE,
	"false":    TOKEN_FALSE,
	"if":       TOKEN_IF,
	"else":     TOKEN_ELSE,
	"return":   TOKEN_RETURN,
	"while":    TOKEN_WHILE,
	"break":    TOKEN_BREAK,
	"continue": TOKEN_CONTINUE,
}

type Lexer struct {
	input        string
	position     int
	readPosition int
	ch           byte
}

func NewLexer(input string) *Lexer {
	l := &Lexer{input: input}
	l.readChar()
	return l
}

func (l *Lexer) readChar() {
	if l.readPosition >= len(l.input) {
		l.ch = 0
	} else {
		l.ch = l.input[l.readPosition]
	}
	l.position = l.readPosition
	l.readPosition++
}

func (l *Lexer) peekChar() byte {
	if l.readPosition >= len(l.input) {
		return 0
	}
	return l.input[l.readPosition]
}

func (l *Lexer) skipWhitespace() {
	for l.ch == ' ' || l.ch == '\t' || l.ch == '\n' || l.ch == '\r' {
		l.readChar()
	}
}

func (l *Lexer) NextToken() Token {
	var tok Token

	l.skipWhitespace()

	switch l.ch {
	case '=':
		if l.peekChar() == '=' {
			ch := l.ch
			l.readChar()
			tok = Token{Type: TOKEN_EQ, Literal: string(ch) + string(l.ch)}
		} else {
			tok = newToken(TOKEN_ASSIGN, l.ch)
		}
	case '+':
		tok = newToken(TOKEN_PLUS, l.ch)
	case '-':
		tok = newToken(TOKEN_MINUS, l.ch)
	case '!':
		if l.peekChar() == '=' {
			ch := l.ch
			l.readChar()
			tok = Token{Type: TOKEN_NOT_EQ, Literal: string(ch) + string(l.ch)}
		} else {
			tok = newToken(TOKEN_BANG, l.ch)
		}
	case '*':
		tok = newToken(TOKEN_ASTERISK, l.ch)
	case '/':
		tok = newToken(TOKEN_SLASH, l.ch)
	case '%':
		tok = newToken(TOKEN_MOD, l.ch)
	case '<':
		tok = newToken(TOKEN_LT, l.ch)
	case '>':
		tok = newToken(TOKEN_GT, l.ch)
	case ';':
		tok = newToken(TOKEN_SEMICOLON, l.ch)
	case ':':
		tok = newToken(TOKEN_COLON, l.ch)
	case ',':
		tok = newToken(TOKEN_COMMA, l.ch)
	case '(':
		tok = newToken(TOKEN_LPAREN, l.ch)
	case ')':
		tok = newToken(TOKEN_RPAREN, l.ch)
	case '{':
		tok = newToken(TOKEN_LBRACE, l.ch)
	case '}':
		tok = newToken(TOKEN_RBRACE, l.ch)
	case '[':
		tok = newToken(TOKEN_LBRACK, l.ch)
	case ']':
		tok = newToken(TOKEN_RBRACK, l.ch)
	case '"':
		tok.Type = TOKEN_STRING
		tok.Literal = l.readString()
	case 0:
		tok.Literal = ""
		tok.Type = TOKEN_EOF
	default:
		if isLetter(l.ch) {
			tok.Literal = l.readIdentifier()
			tok.Type = lookupIdent(tok.Literal)
			return tok
		} else if isDigit(l.ch) {
			tok.Type = TOKEN_INT
			tok.Literal = l.readNumber()
			return tok
		} else {
			tok = newToken(TOKEN_ILLEGAL, l.ch)
		}
	}

	l.readChar()
	return tok
}

func (l *Lexer) readString() string {
	position := l.position + 1
	for {
		l.readChar()
		if l.ch == '"' || l.ch == 0 {
			break
		}
	}
	return l.input[position:l.position]
}

func (l *Lexer) readIdentifier() string {
	position := l.position
	for isLetter(l.ch) {
		l.readChar()
	}
	return l.input[position:l.position]
}

func (l *Lexer) readNumber() string {
	position := l.position
	for isDigit(l.ch) {
		l.readChar()
	}
	return l.input[position:l.position]
}

func lookupIdent(ident string) TokenType {
	if tok, ok := keywords[ident]; ok {
		return tok
	}
	return TOKEN_IDENT
}

func isLetter(ch byte) bool {
	return unicode.IsLetter(rune(ch)) || ch == '_'
}

func isDigit(ch byte) bool {
	return unicode.IsDigit(rune(ch))
}

func newToken(tokenType TokenType, ch byte) Token {
	return Token{Type: tokenType, Literal: string(ch)}
}